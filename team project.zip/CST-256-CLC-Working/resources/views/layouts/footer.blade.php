<html>
	<h5 align="center">Job Finder.... Your Ticket to a New Career!</h5>
	<div class="row">
    	<div class="col-4 mx-auto text-center">
        	<img src="images/logo.png" alt="Site logo">
    	</div>
	</div>
	<h5 align="center">Copyright @2021 Cinematic Station-1</h5>
</html>