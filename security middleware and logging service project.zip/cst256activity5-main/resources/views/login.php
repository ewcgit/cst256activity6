<html>
<body>

<form action="dologin" method="post">
Username: <input type="text" name="username"><br>
Password: <input type="password" name="password"><br>
<input type="submit"></form>

</body>
</html>