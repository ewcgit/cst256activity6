<!DOCTYPE html>
<html lang="en">

<head>
    <title>ICA Page</title>
</head>

<body>@extends('layouts.appmaster')
@section('title', 'ICA Page')
</body>

</html>