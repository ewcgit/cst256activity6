<h5><center>Copyright @2018 My Own Company Name
</center></h5>